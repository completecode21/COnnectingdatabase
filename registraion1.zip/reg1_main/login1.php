<?php  
  $insert = false;
  if(isset($_POST['username'])){
  $server = 'localhost';
  $username = 'root';
  $password = "";

  $conn = mysqli_connect($server,$username,$password);

  if(!$conn){
    die("connection to the db is faild due to ". mysqli_connect_error());
  }

 $username = $_POST['username'];
 $password = $_POST['password'];



 $sql = "INSERT INTO `login`.`login` (`username`, `password`, `login_time`) VALUES ('$username', '$password', current_timestamp());";
  
   if($conn->query($sql) == true){
  //echo "sucessfully Inserted";
  $insert = true;
  }

  else {
  echo "ERROR: $sql <br> $conn->error";

}

$conn->close();


}

?>




<!-- html -->




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
  


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


    <!-- CSS  -->
  <link rel="stylesheet" href="./style.css">

    <!-- icon bootstrap -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
      

    <title>Registration</title>
  </head>
  <body>
   <div class="contaner rounded-top">
    <div class="row mt-5 justify-content-center rounded-top">
        <div class="col-lg-4 bg-warning">
            <h2 class="text-center">Login Now</h2>
           
                  
                        
                 <form action="login1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
                        <input type="text" class="form-control" name="username" placeholder="Username">
                        
                    </div>
                <form action="login1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        
                    </div>
                  

                    <div class="d-grid">
                        <button class="btn btn-success">Login</button>

                        </p>
                        <p>Not Registerd yet?<a href="reg1.php">Register here</a></p>
                    </div>
                
            </form>
        
        
        </div>
    </div>
   </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>