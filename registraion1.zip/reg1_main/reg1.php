<?php 

$insert = false;
if(isset($_POST['first'])){

$server = 'localhost';
$username= 'root';
$password = "";


$conn = mysqli_connect($server,$username,$password);


if(!$conn) {
	 die("connection failed due to " . mysqli_connect_error());

}


$first = $_POST['first'];
$last = $_POST['last'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$cnfpassword = $_POST['cnfpassword'];




$sql = "INSERT INTO `login`.`reg` (`first`, `last`, `email`, `username`, `password`, `cnfpassword`, `reg time`) VALUES ('$first', '$last', '$email',  '$username', '$password', '$cnfpassword', current_timestamp());";




if($conn->query($sql) == true){
	//echo "data sucessfull inserted";
    $insert = true;
}

else{
	echo "ERROR: $sql <br> $conn-error";
}

$conn->close();

}

 ?>




 <!-- html -->



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


    <!-- CSS  -->
  <link rel="stylesheet" href="./style.css">

    <!-- icon bootstrap -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
      

    <title>Registration</title>
  </head>
  <body>
   <div class="contaner rounded-top">
    <div class="row mt-5 justify-content-center rounded-top">
        <div class="col-lg-4 bg-warning">
            <h2 class="text-center">Sign Up Now</h2>
            <p class="text-center">It will take less than a minute</p>
            <form action=" reg1.php" method="post">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                    <input type="name" class="form-control" name="first" placeholder="First Name">
                    
                </div>
            <form action="reg1.php" method="post">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                    <input type="name" class="form-control" name="last" placeholder="Last Name">
                    
                </div>                    <form action="reg1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                        <input type="email" class="form-control" name="email" placeholder="Email-ID">
                        
                    </div>                        <form action="reg1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
                        <input type="name" class="form-control" name="username" placeholder="Set Username">
                        
                    </div>
                <form action="reg1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="cpassword" class="form-control" name="password" placeholder="Set Password">
                        
                    </div>
                <form action="reg1.php" method="post">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" name="cnfpassword" placeholder="Confirm Password">
                            
                    </div>
                  
                    <div class="d-grid">

                        <button class="btn btn-success">Sign Up</button>
                        <p class="text-center text-muted">When you registerd by cliking signup button, You Agree <br>
                            to our <a href="terms.html">Terms & Condition</a> and <a href="pp.html">Privacy Policy</a>
                        </p>
                        <p>Already have an account? <a href="login1.php">Login here</a></p>
                    </div>
                
            </form>
        
        
        </div>
    </div>
   </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>